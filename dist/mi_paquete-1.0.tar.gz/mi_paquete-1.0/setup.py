from setuptools import setup

setup(
    name="mi_paquete",  # Nombre del paquete

    version="1.0",  # Versión del paquete

    description="Estamos haciendo el primer paquete distribuible", #Una breve descripción del paquete

    author="Clase 14 coder - python", #nombre del autor

    author_email="coder@coder.com", #nombre del correo
 
    packages=["mi_paquete"], # Lista de paquetes incluidos en la distribución
)